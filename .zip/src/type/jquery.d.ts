declare module 'jquery' {
  const jQuery: any;
  export = jQuery;
}